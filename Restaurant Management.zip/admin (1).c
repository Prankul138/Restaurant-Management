#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <string.h>


typedef struct
{
  bool InitTermination;
  bool exitStats;
}Admin;

int main()
{

  key_t key = ftok("admin.c",'A');
  int id = shmget(key,sizeof(Admin),0666 | IPC_CREAT);
  Admin *ptr = (Admin*)shmat(id,NULL,0);
  
  
  ptr->InitTermination = false;
  char status;
  printf("Do you want to close the hotel? Enter Y for Yes and N for No.: ");
  while(1)
  {
    
    scanf("%c",&status);
    
    if(status == 'Y')
    {
    ptr->InitTermination = true;
    while(!ptr->exitStats){
    }
    break;
    }
  }
  sleep(4);
 if (shmctl(id, IPC_RMID, NULL) == -1) {
            perror("shmctl error");
            exit(EXIT_FAILURE);
        }
    
    
  return 0;
}
