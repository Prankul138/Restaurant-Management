#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <string.h>



typedef struct
{
    int tableNumber;
    int earnings;
    bool terminationFlag;  // Added termination flag
    bool ReadStats;
    
} Manager;

typedef struct
{
  bool Init_Termination;
  bool exitStats;
}Admin;


bool checkID(int* id,int len)
{
  for(int i=0;i<len;i++)
  {
     if(id[i]==-1)
     {
       return false;
     }
  }
  
  return true;
}


void WriteIncomeData(FILE* fp,int Tbl_Num,int Tbl_income) {
    
    if (fp == NULL) {
        perror("Error opening earnings.txt");
        exit(EXIT_FAILURE);
    }

    
    fprintf(fp, "\nEarning from Table %d: %d INR", Tbl_Num, Tbl_income);
    
}

int main() {
    int numTables;
    
    
     printf("Enter the Total Number of Tables at the Hotel: ");
     scanf("%d", &numTables);
    
    
    
     key_t key[numTables];
     int shmid[numTables];
    
     key_t A_key = ftok("admin.c",'A');
     int A_shmid;
     Admin *A_shmPtr;
    A_shmid = shmget(A_key,sizeof(Admin),0666);
    
    A_shmPtr = (Admin*)shmat(A_shmid,NULL,0);
    
    A_shmPtr->exitStats = false;
    int totalEarnings = 0;
    
  
   
    // Create shared memory segments for communication with waiters
    for (int i = 0; i < numTables; i++) 
    {
        char code  = i + 66;
        key[i] = ftok("waiter.c", code);
        if (key[i] != -1) 
        {    
         
         do
         {
         shmid[i] = shmget(key[i], sizeof(Manager), 0666);
         }while(shmid[i]==-1);
        
        }
        
    }
    
    
    
    FILE *fp = fopen("earnings.txt", "w");
       
    for(int i=0;i<numTables; i++)
    {
      
      if(shmid[i] != -1 )
      {
        
        Manager *shmPtr = (Manager*)shmat(shmid[i], NULL, 0);
           
            while(1)
            {
             if(shmPtr->terminationFlag)
                 break;
            }
         
         totalEarnings += shmPtr->earnings;
        
         WriteIncomeData(fp,shmPtr->tableNumber,shmPtr->earnings);
      }
      
    }
    
   
    
    

      
    // Calculate total wages and profit
    int waiterWages = totalEarnings * 0.4;
    int Profit = totalEarnings - waiterWages;

    // Display total earnings, total wages, and profit
    printf("Total Earnings of Hotel: %d INR\n", totalEarnings);
    printf("Total Wages of Waiters: %d INR\n", waiterWages);
    printf("Total Profit: %d INR\n", Profit);

    // Write total wages and profit to file
    
    if (fp == NULL) {
        perror("Error opening earnings.txt");
        exit(EXIT_FAILURE);
    }
    
    
    fprintf(fp, "\nTotal Earnings of Hotel: %d INR", totalEarnings);
    fprintf(fp, "\nTotal Wages of Waiters: %d INR", waiterWages);
    fprintf(fp, "\nTotal Profit: %d INR", Profit);
    fclose(fp);  //closing earnings.txt
    
   
    
 
 while(1)
 { 
  
  bool Signal = A_shmPtr->Init_Termination;
  if(Signal)
  {
     break;
  }
  
 }
 A_shmPtr->exitStats = true;
    
  
  
   shmdt(A_shmPtr);
   
  // Cleanup - remove shared memory segments
    for (int i = 0; i < numTables; i++) {
        if (shmctl(shmid[i], IPC_RMID, NULL) == -1) {
            perror("shmctl error");
            exit(EXIT_FAILURE);
        }
    }
    
    
   
   printf("Thank you for visiting the Hotel!\n");
   
  
    return 0;
}
