#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<unistd.h>
#include<sys/types.h>
#include<string.h>
#include<sys/wait.h>
#include<sys/ipc.h>
#include<sys/shm.h>

typedef struct
{
  int Order[5][20];
  int numCustomer;
  int count[5];
  bool initTermination;
  bool isValid;
  bool Validated;
  bool restart;
  bool OrderTaken;
  int TableSum;
  int totalAmount;
}Data;

#define Buff_Size  25

typedef struct
{
    int tableNumber;
    int earnings;
    bool terminationFlag;  // Added termination flag
    bool ReadStats;
    
} hotelManager;


int GetPrice(int *menu,int index,int maxLength)
{
   if(index>maxLength)
   {
     return 0;
    }
   return menu[index-1];
}

void readPrice(int *price)
{
  FILE* fl;
  fl = fopen("menu.txt","r");
  char c[100];
  int begin = 0;
  int number;
  while(fscanf(fl,"%*d. %*[^0-9] %d INR\n",&number)==1)
  {
       
    price[begin] = number;
    
    
    begin++;
    
  }
  fclose(fl);
  
  
}

int getNumItems()
{
  FILE* fl;
  fl = fopen("menu.txt","r");
  int num=0;
  char c;
  while(c!=EOF)
  {
     c= fgetc(fl);
     if(c=='\n')
        num++;
  }
  fclose(fl);
  return num;
}




int main()
{

  
  int menu_items = getNumItems();
 
  
  int menuPrice[menu_items];
  
  readPrice(menuPrice);
  
  int WaiterID;
  printf("\nEnter Waiter ID(1-5): ");
  scanf("%d",&WaiterID);
  
  char Wcode = WaiterID+65;
  
  
  
  
  key_t T_key = ftok("table.c",Wcode);
  
  
  if(T_key==-1)
  { 
    perror("Error in ftok");
    return 1;
  }
   

   int shmid;
   Data *shmPtr;
   
   
   shmid = shmget(T_key,sizeof(Data),0666);
   printf("shmid = %d",shmid);
   
   if(shmid==-1)
   {
      perror("shmget error");
      return 1;
   }
     
   shmPtr = (Data*)shmat(shmid,NULL,0);
   
   
   if(shmPtr ==(void*)-1)
   {
     perror("shmat error");
     return 1;
   }
   
   int W_shmid;
   hotelManager *W_shmptr;
   key_t W_key = ftok("waiter.c",Wcode);
   if(W_key==-1)
    { 
     perror("Error in W_ftok");
     return 1;
    }
  
  W_shmid = shmget(W_key,sizeof(hotelManager),0666 | IPC_CREAT);
  if(W_shmid==-1)
   {
      perror("W_shmget error");
      return 1;
   }
  
  W_shmptr = (hotelManager*)shmat(W_shmid,NULL,0);
   if(W_shmptr ==(void*)-1)
   {
     perror("W_shmat error");
     return 1;
   }
   
  W_shmptr->ReadStats = false;
  shmPtr->TableSum = 0;
  int totalSum;
  shmPtr->Validated = false;
 
 while(1){
  shmPtr->Validated = false;
   while(1)
   { 
        
      if(shmPtr->OrderTaken)
      {
       
        break;
      }
   }
   totalSum = 0;
   int price;
  
  
  shmPtr->isValid = true;
  for(int i=0;i<shmPtr->numCustomer;i++)
  {
      
      for(int j=0;j<shmPtr->count[i];j++)
      {
        
        
        if((price = GetPrice(menuPrice,shmPtr->Order[i][j],menu_items))==0)
         {
            
            shmPtr->isValid = false;
            break;
         }
        
        totalSum+=price;
      }
      if(shmPtr->isValid == false){
        totalSum = 0;
        
        break;
      }
  }
  
  shmPtr->Validated = true;
  
  
   if(shmPtr->isValid && shmPtr->Validated)
   {
      
     shmPtr->totalAmount = totalSum;
     
    
      
      while(1)
      {
         if(shmPtr->initTermination == true || shmPtr->restart == true)
         {
           
           break;
         }
      }
     
       if(shmPtr->initTermination && !shmPtr->restart)
       { 
         W_shmptr->earnings = shmPtr->TableSum;
         W_shmptr->tableNumber = WaiterID;
         W_shmptr->terminationFlag = true;
         break;
       }
       
       
   
   }
   
     
   
    shmPtr->Validated = false;
     
   }
   
   
 
 
 printf("\nTotal Bill Amount for Table %d: %d INR",WaiterID,shmPtr->TableSum);
 
 if(shmctl(shmid,IPC_RMID,NULL)==-1){
    perror("shmctl error in waiter.c");
    exit(EXIT_FAILURE);
    
    }
  shmdt(W_shmptr);
   

  return 0;
}

